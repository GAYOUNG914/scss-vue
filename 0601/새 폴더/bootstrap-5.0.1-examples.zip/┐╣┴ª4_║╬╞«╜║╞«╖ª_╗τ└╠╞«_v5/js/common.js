$(function(){
  //script 입력영역
});
